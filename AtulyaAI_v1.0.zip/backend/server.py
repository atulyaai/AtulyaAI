# Backend API server (FastAPI/Django)
from fastapi import FastAPI
app = FastAPI()
@app.get('/')
def read_root():
    return {'message': 'Atulya AI Backend Running'}