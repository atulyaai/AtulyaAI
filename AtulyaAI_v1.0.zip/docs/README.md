# Atulya AI v1.0

This is the initial setup for Atulya AI.