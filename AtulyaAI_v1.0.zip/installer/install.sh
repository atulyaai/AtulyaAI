#!/bin/bash
# Atulya AI Installer v1.0

echo 'Installing Atulya AI...'
